/*
Sınıftaki herkes bir listeye alınacak ve ekrana getirilecek.
Bir şanslı kişi butonu konulacak.
Butona tıklandığında öğrenciler arasından rastgele biri seçilecek.
Listede o kişi farklı renkte / stilde gösterilecek.
*/

const studentData = ['Aytekin', 'Anıl', 'Berna', 'Çağrı', 'Doğu', 'Emine', 'Ferhat', 'Halenur', 'Kutluhan', 'Mümtaz :)', 'Özlem', 'Semih', 'Sena', 'Sercan', 'Ufuk']

const studentList = document.getElementById("listStudents")

for (i=0; i < studentData.length; i++) {
    const listMember = document.createElement('li')
    listMember.innerText = studentData[i]
    studentList.appendChild(listMember)
}


function selectLuckyOne() {
    const randomIndex = Math.floor(Math.random() * studentData.length)
    const randomMember = studentData[randomIndex]
    
    alert(randomMember)
}
  